# History

## [1.37.0]

CHANGES:

- initial K8S 1.37 release
- deprecating 1.34 release
- BREAKING: the `default` ServiceAccount, `default` Role and `default` RoleBinding are not created automatically anymore. Previously they were rendered for every release unless a global pod `serviceAccountName` was configured under `hull.config.templates.pod.global`, and pods without an explicit `serviceAccountName` were wired to the `default` ServiceAccount. Creation is now opt-in via the new `hull.config.general.createDefaultRbacTriplet` switch which defaults to `false`, set it to `true` to restore the previous behavior. Each of the three objects can still be enabled on its own by setting its `enabled` property explicitly. To not silently drop configuration, rendering fails if one of them is customized (`annotations` on the ServiceAccount, `rules` on the Role, a changed `roleRef` or `subjects` on the RoleBinding) but not rendered only because the switch is `false`.
- added `pod.annotations` and `pod.labels` as the preferred place to specify pod template metadata for workload objects, since this metadata ends up on the pod. The existing object instance level `templateAnnotations` and `templateLabels` keys are an equivalent alternative and remain fully supported. Both are merged and where the same key is defined in both, the `pod` level value wins.
- added control over the order of array elements that HULL renders from dictionaries. Previously, array elements were always rendered in alphanumeric order of their dictionary keys which is problematic where Kubernetes attaches meaning to the order. The elements of `containers`, `initContainers`, `volumes`, `env`, `envFrom`, `ports`, `volumeMounts`, service `ports`, ingress `rules`, `paths` and `tls`, role `rules`, `webhooks` and all Gateway API dictionaries now support an integer `order` property (default `0`) by which they are sorted ascending before alphanumeric key order applies. Additionally, `env` variables are automatically rendered after the variables of the same container they reference via `$(VAR_NAME)` in their `value`, making [dependent environment variables](https://github.com/vidispine/hull/issues/414) work out of the box. Without `order` properties and forward references in `env` values the rendered order is unchanged. See the [chart design guide](/hull/files/doc/chart_design.md#ordering-of-array-elements) for details.
- added the previously missing `enabled` property to the JSON schema of all Gateway API array elements that HULL renders from dictionaries. The `enabled` property of GRPCRoute and HTTPRoute `backendRefs` elements is now also evaluated on rendering.
- added the `hull.config.general.assignDefaultServiceAccountToPods` switch (default `true`). Whenever the `default` ServiceAccount is rendered, pods without an explicit `serviceAccountName` are assigned to it as before; set the switch to `false` to opt out of this assignment.
- container `sources` are now applied before `containers` and `initContainers` are ordered, so the `order` property can be provided via container `sources` too. Same as with object instance `sources`, the `enabled` property of pod and container `sources` is not inherited.
- fixed Gateway `listeners` silently dropping `tls` and `allowedRoutes` whenever they had exactly one key, for example `tls` with only `certificateRefs` or `frontendValidation`, or `allowedRoutes` with only `namespaces` or `kinds`.

## [1.36.0]

CHANGES:

- initial K8S 1.36 release
- deprecating 1.33 release
- added new Kubernetes API objects that graduated to stable: `mutatingadmissionpolicy`, `mutatingadmissionpolicybinding`, `validatingadmissionpolicy` and `validatingadmissionpolicybinding`.
- added a new `generic` API object that allows to define generic objects of any sort. While `customresource` objects by definition need to have a `spec` field, this is not the case for `generic` objects, they only need a `kind` and an `apiVersion`. The idea is to offer an escape hatch for creating arbitrary and more exotic objects within the scope of HULL.

FIXES:

- fixed error when using function `hull.object.container.image` outside the scope of an object specification. In this case, missing logging parameters that are autopopulated in the scope of an object definition caused an error. The parameters are now populated with default values to prevent crashes.

## [1.35.3]

FIXES:

- fixed error handling changes because it caused installation failures with [errors in disabled content](https://github.com/vidispine/hull/issues/401) and [sub chart rendering](https://github.com/vidispine/hull/issues/393). Instead of the changed approach (raising every error that occurs during processing) and the original approach (raise only errors in rendered objects), a combined approach is used now. The old error handling practice is restored (raise all visible errors in templates) but extended with raising errors from `conditionals` references, however this is limited to the cases where the associated object is actually rendered. If errors in `conditional` references are recorded for objects that don't get rendered in the end, the errors are dropped.
- improved error messages for better understanding and added object tree paths for direct identification of error source

## [1.35.2]

CHANGES:

- introduce `conditionals` feature to allow conditional rendering of elements in places where `enabled` properties are not available. By binding one or more properties to an arbitrary condition, the rendering of the properties can be indirectly controlled which allows to render or hide sub-trees completely under specified conditions. Check the documentation on chart design for more information. Thanks Armin [sanarena](https://github.com/sanarena) for the feature request!

FIXES:

- improved error handling by storing all found HULL errors in the charts values tree instead of inline in the object YAMLs. Previously, HULL errors were written to the output YAML as the values of the properties where the errors occured and in a final parsing stage the complete YAML tree was searched and errors collected and raised. This approach was performance costly due to the complete parsing of the object YAMLs and also misses errors that happen in places which don't get rendered in the final object YAML. The new approach, that collects all errors separately and later raises them if any are found, is less resource heavy and misses no errors.

## [1.35.1]

CHANGES:

- support subchart usecases with HULL. First, the parsing of HULL relevant fields for transformations has been extended to all of `.Values` instead of `.Values.hull`. This means that HULL transformations in sections outside of `.Values.hull`, such as subchart configurations and `.Values.global`, are now also handled and the result is available for further processing. When adding the `hull.yaml` to a subcharts `templates/zzz` folder in a HULL based parent chart, it becomes possible to use transformations that involve shared data under `.Values.global` and make the result available to parent and sub charts.

FIXES:

- due to [changes made to Helm 3 versions](https://github.com/helm/helm/issues/30587), the behavior for accessing undefined values has changed for specific Helm 3 versions starting with 3.19.5+ and 3.20+. The named versions (and potentially all following Helm 3 patches) exhibit the Helm 4 behavior which leads to an error if an undefined field is accessed. Tests were adapted to differentiate concrete Helm 3 versions and set correct expectations.

## [1.35.0]

CHANGES:

- initial K8S 1.35 release
- deprecating 1.32 release

## [1.34.2]

FIXES:

- fixed inconsistency in usage of ConfigMap `binaryData` entries. Previously, it was possible to provide the binary data via the `binaryData` entries' value dictionary `path` property when it is stored in an external file or directly as a string value to the `binaryData` entries key, omitting the dictionary structure in the value. To restore the symmetry in usage with a value dictionary, it is now possible to alternatively use the `inline` property in the value dictionary to submit `binaryData` entries, this works the same way as using a string value for the `binaryData` directly.

CHANGES:

- ensured compatibility with Helm v4 major releases. It is expected that the vast majority of HULL based use cases is unaffected by the major version of the Helm binary used to manage the chart. See the information in the `README.md` about the existing differences between Helm v3 and Helm v4 which _may_ affect HULL based charts as well. To accomodate for these differences, some tests were relaxed or made context aware to the hosting Helm binaries major version.
- added optional boolean parameter `preEncoded` to Secret `data` entries. If set, the value read from the `inline` property or from an external file with path `path` will not be Base64 encoded by HULL. Instead, if `preEncoded` is set to `true`, the corresponding data content is expected to already be Base64 encoded and HULL will skip auto-encoding it. Setting `preEncoded` to `true` foremost allows to import Base64 encoded (binary) data as from a Secret `data` entry into a pod. Note that when `preEncoded` is set to `true`, the data must be correctly Base64 encoded, otherwise the Kubernetes API will not accept it. The `preEncoded` property applies to Secret `data` only and is ignored on ConfigMap `data` entries. Thanks Armin [sanarena](https://github.com/sanarena) for the feature request!
- added convenient way to replace a customizable string pattern with double opening and closing curly braces in the rendered final YAML. This is especially helpful when packaging `customresource` objects which in its spec may contain templating expressions using double curly braces, popular examples are CRDs for [External Secrets Operator](https://external-secrets.io/latest/) and [Kyverno](https://kyverno.io/). Since these applications have their own templating engine included, their CustomResources typically contain double curly braces. Using this last minute string replacement technique, it becomes possible to execute HULL transformations on such content containing templating expressions partially targeted for Helm and partially targeted for the downstream application. The post-render string replacement of the downstream applications double curly braces allows for a clear separation of the templating stages. To enable the feature, set both `hull.config.general.postRender.globalStringReplacements.openingDoubleCurlyBraces.enabled` and `hull.config.general.postRender.globalStringReplacements.closingDoubleCurlyBraces.enabled` to `true`. Then, whenever down stream double curly braces need replacing in the rendered result, use `{+{` for opening and `}+}` for closing double curly braces and the placeholders will be replaced with `{{` and `}}` respectively last-minute before submittal to the Kubernetes API. If needed, the placeholder values can be customized in the `hull.config.general.postRender.globalStringReplacements` chart configuration.

## [1.34.1]

CHANGES:

- added optional parameters `NOTEMPLATING` and `SERIALIZATION` to `hull.util.tools.virtualdata.data.glob` transformation. The parameters match the behavior of `noTemplating` and `serialization` which are available for processing individual ConfigMap or Secret `data` values. Used with the `hull.util.tools.virtualdata.data.glob` transformation, templating can be skipped and/or serialization performed on all external files captured via the given glob. Thanks [ievgenii-shepeliuk](https://github.com/ievgenii-shepeliuk) for the feature request.

## [1.34.0]

FIXES:

- fixed error thrown due to calculation of hashsums attempted on `secret` and `configmap` object content when the object instance is implicitly disabled. Setting `enabled: false` in the corresponding `_HULL_OBJECT_TYPE_DEFAULT_` instance will implicitly disable rendering for instances which in this case don't explicitly set `enabled: true`. Now, when a `volumeMount` has property `hashsumAnnotation` set to `true` and the targeted `configmap` or `secret` is either implicitly or explicitly disabled in the chart, the calculation of the hashsum is skipped and no errors are thrown.

CHANGES:

- initial K8S 1.34 release
- deprecating 1.31 release
- deprecating `endpoint` object type in accordance with [Kubernetes deprecation](https://kubernetes.io/blog/2025/04/24/endpoints-deprecation/). `endpoint` remains as a configurable object type for the time being but tests for `endpoint` are removed because they fail linting starting with Kubernetes JSON schema version 1.34.

## [1.33.0]

CHANGES:

- initial K8S 1.33 release
- deprecating 1.30 release

## [1.32.3]

FIXES:

- fix CronJob schema missing allowed property `timeZone` as reported [here in this issue](https://github.com/vidispine/hull/issues/360). Thanks for reporting [seniorquico](https://github.com/seniorquico)!

## [1.32.2]

FIXES:

- added schema validation of Gateway API objects created in tests so they are validated properly
- corrected version of created ReferenceGrant objects from `v1` to `v1alpha2`
- fixed Gateway API incorrect schema in field `hostnames` by changing it to an array
- fixed usage of HULL transformations in all fields of Gateway API schema objects in `values.schema.json`. Additional JSON schema properties targeting regular, non-HULL transformation inputs (`pattern`, `default`, `enum`, `minLength` and `maxLength` for strings, `format`, `minimum` and `maximum` for integers) were also applied to the `_HT` inputs which broke usage of them. Solved by strictly separating inputs between `_HT` HULL transformation strings and regular inputs using the `anyOf` property. Thanks to [ievgenii-shepeliuk](https://github.com/ievgenii-shepeliuk) for raising the issue [here in the issues](https://github.com/vidispine/hull/issues/354)

## [1.32.1]

CHANGES:

- added Gateway API objects in version 1.2.0-experimental as main object types to HULL: `backendlbpolicy`, `backendtlspolicy`, `gatewayclass`, `gateway`, `grpcroute`, `httproute`, `referencegrant`, `tcproute`, `tlsroute` and `udproute`. This should make it more comfortable to use them opposed to specifying them using the generic `customresource` object type. Thanks to suggestion from [ievgenii-shepeliuk](https://github.com/ievgenii-shepeliuk) made [in the comments](https://github.com/vidispine/hull/issues/345)
- introducing `sources` feature for pods (`pod` level in the workload specifications) and containers (`initContainers` and `containers` levels in the workload specifications). Using `sources` enables global defaulting of pod and container properties and flexible sharing plus stacking of sets of properties for both pods and containers. Potential usages range from globally enforcing workload security settings, specifying shared minimum or special resource requirements or harmonization of all pods and containers in a chart. See the [chart design guide](/hull/files/doc/chart_design.md) for details. This also closes issues [Add sharedContainers feature](https://github.com/vidispine/hull/issues/305) and [Default security settings](https://github.com/vidispine/hull/issues/310).
- added configurable multi-pass rendering of HULL transformations. This enables forward referencing of values in the YAML tree which was previously not possible. For example, using only a single HULL transformation rendering pass, a field `.Values.hull.config.specific.field_a: _HT*hull.config.specific.field_b`, where `_HT*hull.config.specific.field_b: _HT*hull.config.specific.field_c`, will resolve `field_a` to literal string `_HT*hull.config.specific.field_c`. This is the case because at the time when `field_a` is resolved the value of `field_b` is not yet resolved due to the alphanumeric order of HULL transformation processing. With the new multi-pass default of `hull.config.general.render: 3`, the `field_a: _HT*hull.config.specific.field_c` value is fully resolved to the referenced value of `_HT*hull.config.specific.field_c` in the second pass.

## [1.31.2]

FIXES:

- fixed printed empty string when referencing multi-line strings including line breaks using `_HT*`. Referenced strings via `_HT*` are now bytewise interpreted and printed including newlines using `printf "%s" ($value | quote)` instead of just `$value`. This transports original string as they are literally specified.
- partially fixed referencing large numbers in their original form. Previously if a string contains large numbers > 999999 or values resembling scientific notation, any reference via `_HT*` to the source field interpreted the strings as numbers and converted them to usually undesired scientific notation, changing their value and meaning. Side effect of using `printf "%s" ($value | quote)` for string references, all strings are now transported unchanged. Essentially this makes the [JSON hack mentioned in this issue](https://github.com/vidispine/hull/issues/262) obsolete when the source value is in string form.

CHANGES:

- using `tpl` transformations with `_HT!` now allows in-place serialization of the result using `toJson`, `toPrettyJson`, `toRawJson`, `toYaml` or `toString`. This adds another serialization possibility besides the existing `_HT/` include and `_HT*` get transformation result serialization capabilities. Thanks [ievgenii-shepeliuk](https://github.com/ievgenii-shepeliuk) for the [feature request](https://github.com/vidispine/hull/issues/339).
- made previously required dictionary wrapping of array contents for include/`_HT/` transformations obsolete by correctly making use of to `fromYamlArray` Helm function. If an array was to be returned by a `_HT/` transformation, previously it was needed to wrap it in a dictionary and grab the result from the chosen dictionary key. For example, an transformation like `_HT/result/hull.transformation.do.something` would essentially return an array if the include produces a dictionary with a key `result` that has an array value. Starting with this version, it is possible to call `_HT/hull.transformation.do.something` and the resulting include can directly produce the array.
- restructured documentation on transformations in the `hull/doc/transformation.md` file and removed references to obsolete legacy syntax for transformations.

## [1.31.1]

FIXES:

- fixed follow-up problem with a previous fix for calculation of `hashsumAnnotation` for ConfigMaps or Secrets. In an unlikely case, where a ConfigMap or Secret object has no `data` property set and is then disabled, an unintended error was thrown. ConfigMaps or Secrets with no actual `data` properties can now be disabled without the `hashsumAnnotation` functionality failing.

CHANGES:

- added include shortform transformation `_HT/` to the allowed transformations that can be used within `_HT!` tpl transformations. Similar to using the `_HT*` get syntax within `_HT!` transformations, the `_HT/` include syntax is now embeddable as well. To delimit the `_HT/` arguments from the rest of the `_HT!` content, the `_HT/` block must have a clear ending suffix `/TH_`, similar to bashs `if`/`fi` style. For example, the following syntax now executes the include function within the tpl content: `_HT!{{- printf "%s-%s" _HT/hull.metadata.name:COMPONENT:"tpl-include"/TH_ "example" -}}`
- added possibility to override individual object instance namespaces by setting an optional `namespaceOverride` property on the object instance. CAUTION: creating objects in multiple namespaces _may_ go against Helm principles since normally all objects are created only in the release namespace!  
- added more example `values.yaml` files to `files/examples` and updated outdated ones

## [1.31.0]

CHANGES:

- initial K8S 1.31 release
- deprecating 1.28 release

## [1.30.5]

FIXES:

- fixed issue with using `_HT*` get transformation path syntax within `_HT!` tpl functions when there is an overlap in the paths of the `_HT*` expressions. Since expressions were resolved in order of appearance this could lead to unexpected results where parts of longer expressions were incorrectly overwritten. For example, having get expressions `_HT*hull.config.specific.path.api` and `_HT*hull.config.specific.path.api-user.password` could lead to `_HT*hull.config.specific.path.api` being resolved incorrectly in the latter expresison leaving `-user.password` as an invalid remainder. By sorting the found expressions by descending length instead of order of appearance, it is guaranteed that the longer paths are resolved correctly before any shorter paths that may have an overlap.
- fixed rendering error in case a Secret or ConfigMap that was referred to via the `hashsumAnnotation` feature was set to `enabled: false`. Disabled ConfigMaps or Secrets are now ignored for the calculation of hashsums.

## [1.30.4]

FIXES:

- fixed unwanted fields being merged when using the `sources` feature. When adding multiple sources, the intermediate results were not only merged into the target object but were also added to the sources themselves permanently. If `_HULL_OBJECT_TYPE_DEFAULT_` is in the sources list, this could lead to unwanted fields merged back into object instances that did not have sources specified and only inherited from `_HULL_OBJECT_TYPE_DEFAULT_` implicitly.

## [1.30.3]

FIXES:

- If HULL errors are detected during processing, the processing is not stopped immediately. Instead, all errors are collected and printed after all objects were processed, making it easier to fix multiple problems in one go.
- Multiple HULL errors in one fields value are detectable now and can be shown. Previously only one error per field value was supported.

CHANGES:

- allow combination of bool and include transformations using extended `_HT?/` prefix. Include functions in Helm can only return string values [details in this Helm issue](https://github.com/helm/helm/issues/11231) so it is not possible to set a boolean value via retrieving the result of an include function triggered by `_HT/` include. Using `_HT?/` this is possible now, when the include returns a literal `true` or `false` this is treated as a boolean value using this syntax. See the [transformation documentation](/hull/files/doc/transformations.md) for a detailed explanation and examples.
- allow usage of `_HT*` get transformation path syntax within `_HT!` tpl functions and `_HT?` bool transformations to reference `values.yaml` fields. Opposed to a more implementation heavy extension of `_HT*` to add more flexibility, this solution combines full Go templating flexibility while retaining a concise way of referencing fields in the `values.yaml` via `_HT*` syntax. Additionally, in the case, where only one templating operation is required, the extended `_HT!*` prefix allows to omit the double curly brace wrapping for even more conciseness. To e.g. reference and lower case and trim a `.yaml` suffix of a `values.yaml` field, this expression may be used: `field: _HT!* _HT*hull.config.specific.source | lower | trimSuffix ".yaml"`
- due to the introduction of combined transformations with two characters after `_HT` (`_HT?/` and `_HT!*`), the syntax for `_HT**` with added serialization instructions has been changed too so that `_HT**toJson|hull.config.specific.abc` is the valid syntax now. The former legal form, `_HT*toJson|*hull.config.specific.abc`, is still usable but considered legacy from now on.

## [1.30.2]

CHANGES:

- allow to force render an otherwise disabled object using `hull.object.base.xyz` include by setting FORCE_ENABLED to true. This opens up the possibility to define object instance templates in HULL which are not deployed by HULL itself (by setting `enabled: false`). Instead, the object template can be rendered to a ConfigMap as a full-fledged Kubernetes YAML object which for example can serve as an object template the underlying application creates instances from.

## [1.30.1]

FIXES:

- fix default RoleBinding between default Role and default ServiceAccount. Since namespace was not set for the default ServiceAccount reference, the default RBAC RoleBinding did not apply to the default ServiceAccount as intended.

CHANGES:

- add possibility to access array items in `_HT*` via using the item index for arrays instead of a dictionary key for dictionaries in the dotted path. Accessing into multiple nested arrays is possible like for example `_HT*hull.config.specific.outer-list.0.inner-list.1.key`. Related feature issue is [this one](https://github.com/vidispine/hull/issues/306)
- improve debugging broken YAML errors by including all available info in the generated error message. The error message now contains the actual YAML error and the reference to the specific object type and instance which could not be rendered.
- started adding reusable helper functions for use with `_HT/` in `_util_tools.tpl`. Populating the `data` for a Secret or ConfigMap with external files matching a GLOB pattern can be achieved by using `hull.util.tools.virtualdata.data.glob`. With `hull.util.tools.file.get`, the contents of an external file can be loaded conveniently outside of the ConfigMap and Secret `data` context. Thanks [ievgenii-shepeliuk](https://github.com/ievgenii-shepeliuk) for the ideas [in this isue](https://github.com/vidispine/hull/issues/311)

## [1.30.0]

CHANGES:

- initial K8S 1.30 release
- deprecating 1.27 release

## [1.29.7]

CHANGES:

- added possibility to get values from the charts root with notation `_HT**`

## [1.29.6]

CHANGES:

- added possibility to access the current object instance key and object type in `_HT*` transformations by using special keys `§OBJECT_INSTANCE_KEY§` and `§OBJECT_TYPE§` in the dotted path

## [1.29.5]

FIXES:

- fixed `OBJECT_INSTANCE_KEY` and `OBJECT_TYPE` not existing in context of `_HT?` boolean transformations. Access to `OBJECT_INSTANCE_KEY` and `OBJECT_TYPE` is now provided same as in context of `_HT!` and `_HT/` transformations
- fixed inability to use `OBJECT_INSTANCE_KEY` and `OBJECT_TYPE` for `_HULL_OBJECT_TYPE_DEFAULT_` instances in context of `_HT/` include transformations. This fix allows to combine `postRender` replacements in content created by `_HT/` transformations on a `_HULL_OBJECT_TYPE_DEFAULT_` instance

## [1.29.4]

FIXES:

- fixed problem with running both HULL transformations and `tpl` on `path` content in ConfigMaps and Secrets. After loading the external files content, decide whether to run HULL transformations or `tpl` based on HULL transformation prefix presence
- fixed checks for `virtualFolderDataPathExists` and `virtualFolderDataInlineValid` in the case of Secrets. Due to the Base64 encoding of data any error signaling strings weren't properly detected. With added Base64 decoding of the content for secrets the error checks now work for both ConfigMaps and Secrets
- make all keys within `.Values` available for reference in Secret and ConfigMap `data` `inline` and `path` content templating. Due to obsolete code, all other keys than `hull` were removed from the parent charts `.Values` context when being passed to ConfigMap and Secret for template processing. Thanks again [khmarochos](https://github.com/khmarochos) for pointing out the problem [in this isue](https://github.com/vidispine/hull/issues/288)

## [1.29.3]

CHANGES:

- avoid rendering of empty collections. All `annotations`, `labels` and several other fields, which are explicitly handled by HULL, now are fully omitted if they resolve to empty dictionaries or arrays. This changed behaviour can be reverted by individually choosing to render `emptyAnnotations`, `emptyLabels`, `emptyTemplateAnnotations`, `emptyTemplateLabels` and/or `emptyHullObjects` under `config.global.render`. This default behavior change is in favor of improving compatibility with tools that potentially auto-prune empty collection fields like ArgoCD and thus may have syncing issues with empty collections. In terms of severity this change is considered non-breaking. Down the line, Kubernetes treats missing and empty collection fields in the same way. Note that per the schema, some collection fields are required (`containers` in `pod` and `paths` in `ingress` `rules`) and omitting them or leaving them empty now violates the Kubernetes schema. However, in these cases Kubernetes also verifies that at least one element is in the collection on deployment so the problem only shows earlier. Thanks [alexrimlin](https://github.com/alexrimlin) for the suggestion!

## [1.29.2]

CHANGES:

- removed hardcoded `type: Opaque` and allow to freely set type of Secrets, thanks [khmarochos](https://github.com/khmarochos) for [PR](https://github.com/vidispine/hull/pull/275)
- enabled specification of `configmap` and `secret` `data` inline` fields as dictionaries or lists and added implicit and explicit serialization to `configmap` and `secret` `data` entries. Implicit and automatic serialization takes place for files ending with `.json`(`toPrettyJson`) and files ending with`.yaml` and `.yml`(`toYaml`) if the`inline` content is a dictionary or a list. Explicit serialization is possible using the new `serialization` property for `data` elements and can be applied to dictionary, list and string `inline` entries and string `path` contents. Thanks [khmarochos](https://github.com/khmarochos) for the idea [in this report](https://github.com/vidispine/hull/issues/267)
- added optional serialization arguments to `_HT/` and `_HT*` to serialize dictioanry and lists `toJson`, `toPrettyJson`, `toRawJson`, `toString` or `toYaml`, also thanks [khmarochos](https://github.com/khmarochos) for the idea [in this report](https://github.com/vidispine/hull/issues/267)
- added optional `postRender` option to inject object instance key or object name strings into rendered object YAML. This enables very efficient specification of multiple identical object instances via the `sources` and `_HULL_OBJECT_TYPE_DEFAULT_` feature and last-minute insertion of the actual object instance key or name into the rendered YAML string. Handle with caution since this can invalidate the YAML structure!
- added error checks in HULL to prevent common configuration errors by failing the Helm command. By default verify `image` specifications exist and are valid for all `containers`, files pointed to via `path` physically exist and all tree elements in a `_HT*` references are resolvable

FIXES:

- fixed hashsumAnnotation calculation of secrets incorrectly being done on Base64 encoded value instead of decoded value
- centralized `configmap` and `secret` functionality and tests to guarantee exact same handling whether content is defined `inline` or in a file with `path`. Code difference between `secret` and `configmap` reduced to only late base64 value encoding in the case of secrets.
- improve code in helper functions, thanks [JuryA](https://github.com/JuryA) for [PR](https://github.com/vidispine/hull/pull/277)

## [1.29.1]

CHANGES:

- removed all required field definitions from values.schema.json. Validating required fields is helpful on the output side because it indicates which fields are important in the rendered output but on input side side they block the full potential of efficient defaulting. When present, The JSON schema demands that required fields are added to all individual instances of an object - even when a source or _HULL_OBJECT_TYPE_DEFAULT_ has already set them appropriately and concisely. This leads often to unnecessary bloat and complexity in the values.yaml and therefore the usage of required fields in the JSON schema was dropped favor of cleaner chart design.
- added tests to solidify expectations on workarounds for YAML parser issues with large numbers (unwanted rendering in scientific notation, unwanted interpretation of strings as scientific notation). The issues mentioned [in this report](https://github.com/vidispine/hull/issues/262) cannot be solved in HULL but the tests should from now on indicate if something has changed in Helm about the applicability of the workarounds, thanks [seniorquico](https://github.com/seniorquico)

FIXES:

- fixed bug where imagePullSecrets cannot be overwritten with empty list, thanks [khmarochos](https://github.com/khmarochos)

## [1.29.0]

CHANGES:

- initial K8S 1.29 release
- deprecating 1.26 release

## [1.28.6]

FIXES:

- fix still broken CronJob rendering which is now in line with the rendering style of other object types

## [1.28.5]

FIXES:

- fix broken _HULL_OBJECT_TYPE_DEFAULT_ defaulting of CronJobs properties where all values from _HULL_OBJECT_TYPE_DEFAULT_ or sources where not merged to rendered CronJob instances
- fix missing rendering of embedded Job Kubernetes properties in a Cronjobs jobTemplate where any Kubernetes property of an embedded Job was missing from the rendered output

## [1.28.4]

FIXES:

- fix sources feature not properly working for non-pod based object types
- fix OBJECT_INSTANCE_KEY handling causes error for calls to hull.util.transformation.tpl originating outside of hull.util.transformation

## [1.28.3]

CHANGES:

- introducing more flexible mechanism to populate default values for object intances. It is possible to opt to load default values from zero to multiple object instances by using new hull.base.v1 property sources. All referenced object instances are merged in the provided order to allow sharing definitions between object instances and object types. The default behavior to merge default values from _HULL_OBJECT_TYPE_DEFAULT_ remains intact.

FIXES:

- added icon to Chart.yaml to fix linter warning
- fail with speaking error message instead of hard to decode error message when path elements in get transformations are not found

## [1.28.2]

FIXES:

- extend loosening of schema type to env fields. User input of type float, integer or boolean is now allowed and on rendering a late to string conversion is taking place to guarantee the Kubernetes schema is not violated demanding string values.

## [1.28.1]

FIXES:

- loosen schema types of image tag, annotation and label values. For image tag values user input of type float or integer and for annotation and label values user input of type float, integer and boolean is allowed. On rendering a late to string conversion is taking place to guarantee the Kubernetes schema is not violated demanding string values. Reasoning behind is that for these fields correct quoting of user input is often missing in case of values which are interpreted as non-strings. Allowing a flexible input type and late guaranteed conversion to string helps avoid unncessary and unexpected errors due to user input.
- drop kubeVersion from Chart.yaml to support running hull-demo in lower version clusters, kubeVersion field does not seem to have relevance for hull as a library chart but is copied over to hull-demo Chart.yaml

## [1.28.0]

CHANGES:

- initial K8S 1.28 release
- deprecating 1.25 release
- allow to use implicitly set OBJECT_INSTANCE_KEY and OBJECT_TYPE context variables for accessing an object instance's key and type as strings in the context of transformations executed within an object instance's specification.

## [1.27.1]

CHANGES:

- allow to set an explicit namespaceOverride via chart configuration on the object instances rendered. This is helpful for usage with helm template command so that rendered templates contain a namespace and can be used directly in GitOps style declarative workflows. If no namespaceOverride is provided, the namespace is now still always added to the object instances and falls back to the release namespace.

## [1.27.0]

CHANGES:

- initial K8S 1.27 release
- deprecating 1.24 release

## [1.26.2]

CHANGES:

- by adding property hashsumAnnotation: true to a pods volumeMount, env or envFrom referencing a ConfigMap or Secret, a pod restart can be enforced in case of changed contents. This works by calculation of a hashsum of the contents and adding it to the pods template annotations. This is recommended practice as documented in the [Helm documentation](https://helm.sh/docs/howto/charts_tips_and_tricks/#automatically-roll-deployments) in order to handle applications that require restarts on certain configuration changes.

## [1.26.1]

CHANGES:

- add metadataNameOverride possibility to Hull.Object.Base to allow setting an object instance metadata.name that is different from the implicit component key. This enables special use-cases where e.g. the definition of a custom resource instance is done in the chart's values.yaml under a fixed key and the CustomResources actual instance name - maybe playing an important role for the operator functionality - is only set at deployment time dynamically

## [1.26.0]

CHANGES:

- initial K8S 1.26 release
- deprecating 1.23 release
- build and release hull-demo chart for easy demoing and bootstrapping HULL based Helm Charts

FIXES:

- improved schema structure for centrally defined probe configurations ([PR](https://github.com/vidispine/hull/pull/202), thanks [matthias4217](https://github.com/matthias4217))
- fix merging order for tests with additional overlay values.yamls

## [1.25.10]

FIXES:

- when a dictionary structure contains a _HULL_TRANSFORMATION_ key for producing dynamically rendered key-value content and additional static keys side-by-side, transformations were not being correctly processed for the structures beneath the static key contents
- some minor documentation fixes (links in main README.md, broken structures)

## [1.25.9]

FIXES:

- fixed incorrect schema structure for imagePullPolicy enums (thanks [matthias4217](https://github.com/matthias4217))

## [1.25.8]

FIXES:

- fixed general linter error due to bad whitespace chomping between YAML objects, this did not affect template rendering however (<https://github.com/vidispine/hull/issues/186>)
- added strict linting to test cases, now all cases must not emit linting WARNINGs or ERRORs to be considered successful

## [1.25.7]

FIXES:

- extend transformation scope from objects spec to Values.hull when computing initial transformations, fixes cases with first transformation resolving to another transformation which is then not resolved itself
- speed up rendering by only run transformations once on complete Values.hull dictionary instead of running it once for each object type

## [1.25.6]

FIXES:

- render emtpy string instead of `<nil>` when ConfigMap or Secret inline input is nil pointer

CHANGES:

- add debug option renderNilWhenInlineIsNil to print out `<nil>` instead of empty string when an inline value resolves to a nil pointer
- add debug option renderPathMissingWhenPathIsNonExistent to print out information about a missing file for a path value instead of an empty string when a path value does not resolve to an actual file

## [1.25.5]

CHANGES:

- changed transformation notation for include for better readability

FIXES:

- fixed and improve include transformation

## [1.25.4]

CHANGES:

- add new include transformation and short form to allow compact usage of includes with minimum typing in values.yaml.

FIXES:

- quote versions in Chart.yaml (<https://github.com/vidispine/hull/issues/169>)

## [1.25.3]

CHANGES:

- for ConfigMap and Secret data, inline specification now always has precedence over path specification to make sure that content can always be overwritten at configuration time if required
- add active property to allow selecting amongst multiple volume definitions if they exist, eg. if a volume is defaulting to an emptyDir and is to be made a persistentVolumeClaim, the value of the active property (if specified) declares the concrete volume to render, otherwise Kubernetes will not accept multiple volume type definitions for a volume.

## [1.25.2]

CHANGES:

- remove required property for endpoints and selector in ServiceMonitors from schema to allow better defaulting

## [1.25.1]

CHANGES:

- add debug option renderBrokenHullGetTransformationReferences which allows to render HULL charts containing broken Get transformation references with non existing keys. By rendering these transformations with an informative placeholder instead of failing the chart rendering the broken references can be traced and fixed more easily before finishing writing the chart
- allows to use placeholder § to escape dots within key names so GET references also work when dots are within key names

## [1.25.0]

CHANGES:

- initial K8S 1.25 release
- deprecating 1.22 release
- removed PodSecurityPolicy

## [1.24.1]

CHANGES:

- improve intro documentation and add KH quote
- add Helm 3.9.0 to tests
- add option noObjectNamePrefixes to remove all object name prefixes globally

## [1.24.0]

CHANGES:

- initial K8S 1.24 release
- deprecating 1.21 release
- added option to include ConfigMap binaryData from external path

## [1.23.4]

CHANGES:

- added new objects Namespace, EndpointSlice and LimitRange

- update documentation

FIXES:

- disabling RBAC did not prevent rendering of Roles and ClusterRoles

## [1.23.3]

CHANGES:

- added transformation pattern to array fields from ServiceMonitor definition
- update documentation

FIXES:

- HULL rules must be dictionary for roles in values.yaml

## [1.23.2]

CHANGES:

- get transformation can now return complex dictionaries and array types
- introduce selector transformation and _HT& shortcut

FIXES:

- use fixed name template lower-case 'release-name' for helm template command compatibility with Helm 3.8. Previous versions created upper case 'RELEASE-NAME' by default for Release.Name which is changed to lowercase 'release-name' with Helm 3.8

## [1.23.1]

CHANGES:

- allow to choose between rendering to single file or multiple files per object type to potentially eliminate performance penalty due to having one file only
- add test environments for both single and multi file usage
- add two example values.yamls

FIXES:

- allow using 63 instead of 54 chars for a fullname and name override
- remove dots end of labels and names

## [1.23.0]

CHANGES:

- initial K8S 1.23 release
- deprecating 1.20 release

## [1.22.13]

FIXES:

- changed probe port schema to anyOf to avoid clash when using oneOf transformation or string

## [1.22.12]

FIXES:

- allow mixed transform only when dictionary is returned from transformation and other keys exist besides transformation trigger

## [1.22.11]

CHANGES:

- added tests for get transformation results
- make every object field subjectable to string transformations irrelevant of input type by large scale extension of JSON schema

FIXES:

- using a get transformation to poulate Configmap/Secret contents produced bad
character sequences

## [1.22.10]

CHANGES:

- added short forms for transformations
- documentation improved

## [1.22.9]

CHANGES:

- fix enabled properties allowed on policyrules in roles, envfrom and tls in ingresses
- allow shorter form of (index . "$") to access parent context

## [1.22.8]

CHANGES:

- add hull.util.transformation.bool transformation

- BREAKING! change fields for registry population to overwrite any explicit registry fields

## [1.22.7]

CHANGES:

- add CHANGELOG.md
- add ingressclass objects as main objects
- allow to specify rules in roles key-value based instead of as an array (array also supported)
- add unit tests for ClusterRole and ClusterRoleBindings

FIXES:

- clusterrole and clusterrolebinding objects with enabled=false or nulled were rendering incorrectly as empty objects
- cronjob pods must not have selector set

## [1.22.6]

CHANGES:

- allow enabled property on all key-value pair HULL objects
- allow to use string as input for enabled property in order to use HULL transformations on enabled properties
